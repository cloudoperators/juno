---
name: datagrid-filters-toolbar
description: "Build the DataGrid header as a three-zone composition: Zone 1
  (sorting + overflow menu + primary action in a bare Stack), Zone 2 (filters
  via Select+ComboBox in an InputGroup, SearchInput, active filter Pills, in a
  DataGridToolbar), Zone 3 (bulk actions + item count + refresh in a
  DataGridToolbar). Use when a DataGrid needs filtering, search, sorting, or
  bulk actions."
metadata:
  library: "@cloudoperators/juno-ui-components"
  purpose: >
    Teach an agent the DataGrid header composition pattern, which no component
    prop or type signature expresses: there is no Filter component, filters are
    assembled from Select/ComboBox/InputGroup/SearchInput/Pill, and the header
    is three optional zones with specific wrapping, backgrounds, and behavior.
sources:
  - src/components/DataGrid/DataGridHeader.stories.tsx
  - src/components/DataGridToolbar/DataGridToolbar.component.tsx
requires:
  - datagrid
---

# Build the DataGrid header (filters, search, sorting, bulk actions)

**Prerequisite:** the `datagrid` skill. This skill covers the interactive header
that sits above the grid.

The DataGrid header is a **composition pattern, not a single component.** There
is **no `Filter` component** — a filter UI is assembled from existing
primitives. The header is organized into up to **three zones**, each optional,
and so is every element inside a zone. Build only what the specific grid needs;
if none of the zones are needed, reconsider whether a DataGrid is the right
pattern at all.

| Zone | Holds | Wrapper / background |
| --- | --- | --- |
| **1 — Actions** | predefined filter tabs, sort control, global-actions overflow menu, primary action | **bare `Stack`, no background** |
| **2 — Filters & Search** | filter inputs, `SearchInput`, active filter `Pill`s + "Clear filters" | its own `DataGridToolbar` |
| **3 — Grid state** | bulk actions (select-all + action menu), item count, last update + refresh | its own `DataGridToolbar` |

`DataGridToolbar` is only a styled wrapper (background, padding, bottom border)
for Zones 2 and 3. Zone 1 never uses it. Put a `Stack` inside each
`DataGridToolbar` to position content.

## Wrapping rules

- Wrap the **whole header** (all zones) in a vertical `Stack`.
- Wrap the **header + the `DataGrid`** together in an **outer** vertical `Stack`.
- Zones 2 and 3 are **separate** `DataGridToolbar` blocks — do not merge them
  into one band.

```tsx
import { Stack, DataGridToolbar, SearchInput } from "@cloudoperators/juno-ui-components"

// Shape only: a header Stack holding one toolbar zone, ready to sit above a DataGrid.
export const HeaderShell = () => (
  <Stack direction="vertical">
    <DataGridToolbar>
      <Stack distribution="end" alignment="center">
        <SearchInput placeholder="Search servers…" />
      </Stack>
    </DataGridToolbar>
  </Stack>
)
```

## Zone 1 — Predefined filter tabs, sorting, actions (bare `Stack`)

- **Predefined filter tabs** (far left, optional): tabs that apply a fixed,
  pre-configured filter set — e.g. "All" / "Deleted". They must always operate
  on the **same** entity set, just filtered differently. Do **not** misuse them
  as navigation to unrelated data; use page-level tabs for that.
- **Sorting:** a `Select` to choose the sort field + a `SortButton` to toggle
  direction.
- **Overflow menu:** a `PopupMenu` for global actions other than the primary one.
- **Primary action:** the single most likely action (often "Create"), a
  `variant="primary"` `Button` on the right.

Zone 1 sits directly in a `Stack` with **no `DataGridToolbar`**.

## Zone 2 — Filters & search (`DataGridToolbar`)

- **Filter inputs:** depending on the data, a single `Select`, or a `Select` +
  `ComboBox` (and sometimes a `TextInput`) grouped in an `InputGroup`. The
  `Select` picks the attribute; the `ComboBox`/`TextInput` picks the value.
- **Search:** a `SearchInput`. Set the placeholder to manage expectations about
  what is searched (e.g. "Search by name").
- **Active filter pills:** one `Pill` (`closeable`) per currently-applied
  filter, followed by a "Clear filters" `Button` (`size="xs"`).

## Zone 3 — Grid state, bulk actions, refresh (`DataGridToolbar`)

- **Bulk actions (left):** a select-all `Checkbox` + a `PopupMenu` of bulk
  actions. Requires a `Checkbox` in each row. The select-all checkbox is
  **tri-state**: unchecked (none selected), indeterminate (some), checked (all);
  clicking while unchecked/indeterminate selects all, clicking while checked
  deselects all. Bulk-action controls stay disabled until at least one row is
  selected.
- **Item count (center):** total items visible across the whole set (not just
  the current page). When a filter or search is active, show "X of Y".
- **Last update + refresh (right):** the last-refresh timestamp and a refresh
  `Button`.

## Full composition

The fully-featured header: Zone 1 as a bare `Stack`, Zones 2 and 3 each in their
own `DataGridToolbar`, all inside a header `Stack`, with the `DataGrid` below —
all wrapped in an outer `Stack`. (Illustrative; omit any zone or element you
don't need.)

```tsx no-check
<Stack direction="vertical">
  <Stack direction="vertical">
    {/* Zone 1 — bare Stack, no background */}
    <Stack distribution="end" alignment="center" gap="2" className="pb-2">
      <Stack gap="2">
        <Stack gap="0.5">
          <Select width="auto" label="Sort by" className="min-w-40">
            <SelectOption value="name" label="Name" />
            <SelectOption value="status" label="Status" />
          </Select>
          <SortButton order={sortOrder} onChange={setSortOrder} />
        </Stack>
        <Stack gap="0.5">
          <PopupMenu>
            <PopupMenuToggle as={React.Fragment}>
              <Button icon="moreVert" title="More actions" />
            </PopupMenuToggle>
            <PopupMenuOptions>
              <PopupMenuItem label="Export CSV" />
            </PopupMenuOptions>
          </PopupMenu>
          <Button label="Create Server" variant="primary" />
        </Stack>
      </Stack>
    </Stack>

    {/* Zone 2 — DataGridToolbar: filters + search + pills */}
    <DataGridToolbar>
      <Stack direction="vertical" gap="2">
        <Stack distribution="between" alignment="center">
          <InputGroup>
            <Select width="auto" label="Filter by" className="min-w-44">
              <SelectOption value="region" label="Region" />
              <SelectOption value="status" label="Status" />
            </Select>
            <ComboBox>
              <ComboBoxOption value="eu-west-1" label="eu-west-1" />
              <ComboBoxOption value="us-east-1" label="us-east-1" />
            </ComboBox>
          </InputGroup>
          <SearchInput placeholder="Search servers…" />
        </Stack>
        <Stack gap="2" wrap>
          <Pill pillKey="Region" pillValue="eu-west-1" closeable />
          <Button label="Clear filters" size="xs" />
        </Stack>
      </Stack>
    </DataGridToolbar>

    {/* Zone 3 — separate DataGridToolbar: bulk actions + count + refresh */}
    <DataGridToolbar>
      <Stack distribution="between" alignment="center" className="text-sm">
        <Stack gap="2" alignment="center">
          <Checkbox aria-label="Select all items" />
          <PopupMenu className="flex items-center">
            <PopupMenuToggle as={React.Fragment}>
              <Button size="xs" icon="moreVert" label="Actions" />
            </PopupMenuToggle>
            <PopupMenuOptions>
              <PopupMenuItem label="Delete" />
            </PopupMenuOptions>
          </PopupMenu>
        </Stack>
        <span>Showing 2 of 4 servers</span>
        <Stack gap="2" alignment="center">
          <span>Last update: 20.05.2026 @09:41</span>
          <Button label="Update" size="xs" />
        </Stack>
      </Stack>
    </DataGridToolbar>
  </Stack>

  {/* The DataGrid itself — see the `datagrid` skill */}
  <DataGrid columns={6} minContentColumns={[0, 5]}>
    {/* head row + rows, each with a leading Checkbox cell and trailing actions cell */}
  </DataGrid>
</Stack>
```

## Pitfalls

- **Looking for a `Filter` component.** There isn't one. Compose filters from
  `Select` + `ComboBox` (in an `InputGroup`) + `SearchInput` + `Pill`.
- **Putting Zone 1 in a `DataGridToolbar`.** Zone 1 is a bare `Stack` with no
  background. Only Zones 2 and 3 use `DataGridToolbar`.
- **Merging Zones 2 and 3** into one toolbar. They are separate blocks.
- **Forgetting the wrappers.** Header zones go in a vertical `Stack`; that header
  plus the `DataGrid` go in an outer vertical `Stack`.
- **Bulk actions without row checkboxes**, or a non-tri-state select-all, or
  active controls while nothing is selected.
- **Static item count** when filtering — show "X of Y" while a filter/search is
  active.

## Done when

- Only the needed zones are rendered; each unused zone/element is omitted.
- Zone 1 is a bare `Stack`; Zones 2 and 3 each sit in their own
  `DataGridToolbar`; the header is a vertical `Stack`; header + grid share an
  outer vertical `Stack`.
- Filters are composed from primitives (no imagined `Filter` component) with a
  `Pill` per active filter and a "Clear filters" control.
- Bulk actions use a tri-state select-all `Checkbox` + a row `Checkbox` each,
  disabled until a selection exists; the count shows "X of Y" when filtered.
