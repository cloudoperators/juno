---
name: datagrid
description: Display a collection of structured data as a Juno DataGrid
  (DataGrid, DataGridRow, DataGridCell, DataGridHeadCell). Use when building a
  sortable/filterable table of resources; covers columns, minContentColumns, and
  when NOT to use a DataGrid.
metadata:
  library: "@cloudoperators/juno-ui-components"
  purpose: >
    Teach an agent to render tabular/collection data with Juno's DataGrid
    primitives instead of a raw HTML table, including correct column sizing and
    the cells-per-row invariant, and to recognize when a DataGrid is the wrong
    pattern.
sources:
  - src/components/DataGrid/DataGrid.component.tsx
  - src/components/DataGrid/DataGrid.stories.tsx
---

# Build a Juno DataGrid

The DataGrid is Juno's primary pattern for displaying a collection of structured
data — a list of resources, entities, or items that share a common set of
attributes. **Never build a resource list with a raw `<table>`, `<tr>`, or CSS
grid.** Use the DataGrid primitives from `@cloudoperators/juno-ui-components` so
spacing, theming, alignment, and accessibility (`role="grid"`) come for free.

## When to use a DataGrid

Use a DataGrid when:

- You display a list of items that share a consistent set of attributes.
- Users need to scan, compare, sort, or filter across many items at once.
- Items are actionable — users can select, edit, delete, or navigate to them.
- The data is dense enough that cards or tiles would waste space or obscure
  comparability.

Do **not** use a DataGrid — pick another pattern — when:

- You show a single item or entity → use a detail view, panel, or card.
- The data has no structure that casts to columns → a simple list may suffice.
- The task is reading long-form content rather than scanning attributes.

## Anatomy

A DataGrid is composed from primitives, not configured through props:

- `DataGrid` — the grid container. Set `columns` to the number of columns.
- `DataGridRow` — one row. The first row is the head row.
- `DataGridHeadCell` — a column label. Always include a head row unless the
  column meaning is self-evident from context, or a cell's content is synthesized
  and cannot be labelled with a short term. Use an empty `<DataGridHeadCell />`
  to reserve a column that has no label (e.g. a checkbox or actions column).
- `DataGridCell` — one cell. **Every row must contain exactly `columns` cells**
  (count empty head/action cells too), or the grid misaligns.
- `DataGridFoot` — optional footer for pagination or set-level metadata.

The interactive header above the grid (filters, search, sorting, bulk actions)
is a separate composition pattern — see the `datagrid-filters-toolbar` skill.

## Core usage

A minimal three-column grid. Note the head row of `DataGridHeadCell`s and that
every body row has the same number of `DataGridCell`s as `columns`:

```tsx
import { DataGrid, DataGridRow, DataGridHeadCell, DataGridCell } from "@cloudoperators/juno-ui-components"

const servers = [
  { id: "1", name: "node-prod-01", region: "eu-west-1", status: "Running" },
  { id: "2", name: "node-prod-02", region: "eu-west-1", status: "Stopped" },
]

export const ServerTable = () => (
  <DataGrid columns={3}>
    <DataGridRow>
      <DataGridHeadCell>Name</DataGridHeadCell>
      <DataGridHeadCell>Region</DataGridHeadCell>
      <DataGridHeadCell>Status</DataGridHeadCell>
    </DataGridRow>
    {servers.map((server) => (
      <DataGridRow key={server.id}>
        <DataGridCell>{server.name}</DataGridCell>
        <DataGridCell>{server.region}</DataGridCell>
        <DataGridCell>{server.status}</DataGridCell>
      </DataGridRow>
    ))}
  </DataGrid>
)
```

## Column sizing

By default every column shares space evenly. Two props cover almost every case:

- `minContentColumns={[...]}` — indices of columns that should shrink to their
  content width (checkbox column, actions column, short status). All other
  columns share the remaining space. Indices are **0-based**.
- `columnMinSize` / `columnMaxSize` — the `minmax()` bounds applied to the
  non-min-content columns (defaults `"0px"` / `"auto"`).

```tsx
import { DataGrid, DataGridRow, DataGridHeadCell, DataGridCell } from "@cloudoperators/juno-ui-components"

// 6 columns; column 0 (checkbox) and column 5 (actions) size to content.
export const Grid = () => (
  <DataGrid columns={6} minContentColumns={[0, 5]}>
    <DataGridRow>
      <DataGridHeadCell />
      <DataGridHeadCell>Name</DataGridHeadCell>
      <DataGridHeadCell>Region</DataGridHeadCell>
      <DataGridHeadCell>Status</DataGridHeadCell>
      <DataGridHeadCell>Availability Zone</DataGridHeadCell>
      <DataGridHeadCell />
    </DataGridRow>
  </DataGrid>
)
```

Reach for `gridColumnTemplate` (a raw CSS `grid-template-columns` string) only
when `columns` + `minContentColumns` genuinely cannot express the layout; it
overrides all other sizing props.

## Cells

- `verticalAlignment="center" | "top"` — set per cell, or once on the whole grid
  via `DataGrid`'s `cellVerticalAlignment` (defaults to `"center"`). Use `"top"`
  on grids whose cells hold multi-line content.
- `colSpan={n}` — span multiple columns (e.g. an empty-state row).
- `nowrap` — prevent wrapping in a cell.

Place interactive content directly inside a cell — a `Checkbox` for row
selection, a `PopupMenu` for per-row actions, a `Button`, etc.

## Pitfalls

- **Raw HTML tables.** `<table>`/`<tr>`/`<td>` for a resource list is wrong even
  if styled — it loses theming and the grid semantics. Use the primitives.
- **Cell/column mismatch.** If a row has fewer or more `DataGridCell`s than
  `columns`, the layout breaks. Reserve label-less columns with empty
  `<DataGridHeadCell />` and empty `<DataGridCell />`.
- **Skipping the head row.** Include `DataGridHeadCell`s unless the columns are
  genuinely self-evident.
- **Styling columns by hand.** Prefer `columns` + `minContentColumns` over a
  bespoke `gridColumnTemplate`.

## Done when

- The list renders with `DataGrid` + `DataGridRow` + `DataGridHeadCell` +
  `DataGridCell` — no raw table or ad-hoc grid.
- Every row (head and body) has exactly `columns` cells.
- Content-width columns (checkbox/status/actions) are listed in
  `minContentColumns`.
- If the grid needs filtering, search, sorting, or bulk actions, the header is
  built with the `datagrid-filters-toolbar` skill.
